"""
etl_acs_pull.py

Pulls ACS 5-year estimates for the 8 in-scope tables (DP04, DP05, S1101, S1901,
S2501, B19037, B25007, B25118) for every resolved geography, for years 2010-2024,
and loads them into the `acs_estimates` table (schema_v1.sql).

Requires:
    - geography_resolved.csv (output of resolve_geography.py, plus the manually
      confirmed rows from geography_needs_review.csv merged back in)
    - a Census API key, set as the CENSUS_API_KEY environment variable
      (never hardcode it here -- see note from earlier in our conversation)

The Census API caps requests at 50 variables per call, so each table's variable
list gets fetched in batches. Detail tables (B-prefixed) live at a different
dataset path than Data Profile (DP-prefixed) and Subject (S-prefixed) tables.
"""

import os
import time
import requests
import pandas as pd
from sqlalchemy import create_engine

CENSUS_API_KEY = os.environ["CENSUS_API_KEY"]  # fails loudly if not set -- good
DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://localhost/census_dashboard")

YEARS = range(2010, 2025)  # ACS5 vintages: 2010 (2006-2010) through 2024 (2020-2024)

TABLES = {
    # table_id: dataset path suffix under /data/{year}/acs/acs5{suffix}
    "DP04": "/profile",
    "DP05": "/profile",
    "S1101": "/subject",
    "S1901": "/subject",
    "S2501": "/subject",
    "B19037": "",
    "B25007": "",
    "B25118": "",
}

BATCH_SIZE = 45  # stay under the 50-variable API limit, leave room for NAME


def get_table_variables(year: int, table_id: str, dataset_suffix: str) -> dict:
    """Returns {variable_code: label} for every variable belonging to table_id."""
    url = f"https://api.census.gov/data/{year}/acs/acs5{dataset_suffix}/variables.json"
    resp = requests.get(url, timeout=60)
    resp.raise_for_status()
    all_vars = resp.json()["variables"]

    table_vars = {}
    for code, meta in all_vars.items():
        if meta.get("group") == table_id and (code.endswith("E") or code.endswith("M")):
            table_vars[code] = meta.get("label", code)
    return table_vars


def fetch_batch(year: int, dataset_suffix: str, var_codes: list, geo_clause: dict) -> pd.DataFrame:
    url = f"https://api.census.gov/data/{year}/acs/acs5{dataset_suffix}"
    params = {
        "get": "NAME," + ",".join(var_codes),
        "key": CENSUS_API_KEY,
        **geo_clause,
    }
    resp = requests.get(url, params=params, timeout=60)
    resp.raise_for_status()
    rows = resp.json()
    df = pd.DataFrame(rows[1:], columns=rows[0])
    return df


def pull_table_for_year(year: int, table_id: str, dataset_suffix: str, state_fips_list: list) -> pd.DataFrame:
    table_vars = get_table_variables(year, table_id, dataset_suffix)
    var_codes = sorted(table_vars.keys())

    all_frames = []
    for state_fips in state_fips_list:
        for geo_type, geo_for in [("place", "place:*"), ("county", "county:*")]:
            geo_clause = {"for": geo_for, "in": f"state:{state_fips}"}
            for i in range(0, len(var_codes), BATCH_SIZE):
                batch = var_codes[i:i + BATCH_SIZE]
                try:
                    df = fetch_batch(year, dataset_suffix, batch, geo_clause)
                except requests.HTTPError as e:
                    print(f"  [WARN] {table_id} {year} state {state_fips} {geo_type} batch {i}: {e}")
                    continue
                df["geo_type"] = geo_type
                df["state_fips"] = state_fips
                all_frames.append(df)
                time.sleep(0.2)  # be polite to the API

    if not all_frames:
        return pd.DataFrame()

    combined = pd.concat(all_frames, ignore_index=True)
    return combined, table_vars


def reshape_to_long(raw_df: pd.DataFrame, table_vars: dict, table_id: str, year: int,
                     geography_lookup: pd.DataFrame) -> pd.DataFrame:
    """Wide (one row per geography, one column per variable) -> long fact rows."""
    id_cols = ["geo_type", "state_fips", "place", "county", "NAME"]
    id_cols = [c for c in id_cols if c in raw_df.columns]
    value_cols = [c for c in raw_df.columns if c in table_vars]

    long_df = raw_df.melt(id_vars=id_cols, value_vars=value_cols,
                           var_name="variable_code", value_name="raw_value")

    # Build geoid: state FIPS + place/county FIPS
    def build_geoid(row):
        local_fips = row.get("place") or row.get("county")
        return f"{row['state_fips']}{local_fips}"

    long_df["geoid"] = long_df.apply(build_geoid, axis=1)
    long_df = long_df[long_df["geoid"].isin(geography_lookup["geoid"])]  # keep only resolved geos

    # Split estimate vs. margin of error (variable codes end in E or M)
    long_df["is_moe"] = long_df["variable_code"].str.endswith("M")
    long_df["base_code"] = long_df["variable_code"].str.rstrip("EM")

    pivoted = long_df.pivot_table(
        index=["geoid", "base_code"], columns="is_moe", values="raw_value", aggfunc="first"
    ).reset_index()
    pivoted.columns = ["geoid", "variable_code", "estimate", "moe"] if True else pivoted.columns
    pivoted["year"] = year
    pivoted["table_id"] = table_id
    pivoted["variable_label"] = pivoted["variable_code"].map(
        lambda c: table_vars.get(c + "E", table_vars.get(c, c))
    )
    return pivoted[["geoid", "year", "table_id", "variable_code", "variable_label", "estimate", "moe"]]


def main():
    geography = pd.read_csv("geography_resolved.csv")
    state_fips_list = sorted(geography["geoid"].str[:2].unique())

    engine = create_engine(DATABASE_URL)

    for table_id, dataset_suffix in TABLES.items():
        for year in YEARS:
            print(f"Pulling {table_id} for {year}...")
            result = pull_table_for_year(year, table_id, dataset_suffix, state_fips_list)
            if not result or result[0].empty:
                print(f"  no data returned, skipping")
                continue
            raw_df, table_vars = result
            long_df = reshape_to_long(raw_df, table_vars, table_id, year, geography)
            long_df.to_sql("acs_estimates", engine, if_exists="append", index=False, method="multi")
            print(f"  loaded {len(long_df)} rows")


if __name__ == "__main__":
    main()
